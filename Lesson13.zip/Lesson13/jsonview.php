<?php
 
$contact = file_get_contents("CustomerInfo.json");
 
$display="<div id='customer'><h1>Address Information</h1>";
 
    $display="<div id='customer'><h1>Contact Listing</h1>";
    $contactObj = json_decode($contact);
    foreach ($contactObj->contactList as $people){
      $id = $people->id;
      $fName = $people->f_Name;
      $lName = $people->L_Name;       
      $display.= "<hr><p>ID:" . $id . "</p>" ."<hr><p>First Name: " . $fName . "&nbsp;&nbsp;  Last Name: " . $lName . "</p>";
     }
     $display .= "</div>";
     include 'BeginNav.php';
     echo $display;
     include 'EndNav.php';
?>
