<?php
include 'connect.php';

if (!$_POST) {
	//haven't seen the form, so show it
	$display_block = <<<END_OF_BLOCK
	<form method="post" action="$_SERVER[PHP_SELF]" class="form">
<h1>Create a new authorized user</h1><br/>
	<fieldset>
	<label>First Name:</label><br/>
    <input type="text" name="f_name" size="20" maxlength="75" required="required" /><br/>
    <label>Last Name:</label><br/>
	<input type="text" name="l_name" size="30" maxlength="75" required="required" /><br/>
    <label> Email Adress:</label><br/>
    <input type="text" name="email" size="30" maxlength="25"/><br/>
    <label> UserName:</label><br/>
    <input type="text" name="username" size="30" maxlength="75"/><br/>
    <label> Password:</label><br/>
    <input type="text" name="password" size="30" maxlength="75"/><br/>
	</fieldset>
	<button type="submit" name="submit" value="send" class="bg-success">Add Authorized User</button>
	</form>
END_OF_BLOCK;

} else if ($_POST) {
	//time to add to tables, so check for required fields
	if (($_POST['f_name'] == "") || ($_POST['l_name'] == "")) {
		header("Location: addAuthUser.php");
		exit;
	}

	//connect to database
	doDB();

	//create clean versions of input strings
	$safe_f_name = mysqli_real_escape_string($mysqli, $_POST['f_name']);
	$safe_l_name = mysqli_real_escape_string($mysqli, $_POST['l_name']);
	$safe_email = mysqli_real_escape_string($mysqli, $_POST['email']);
    $safe_username = mysqli_real_escape_string($mysqli, $_POST['username']);
    $safe_password = mysqli_real_escape_string($mysqli, $_POST['password']);

	//add to master_name table
	$add_auth_sql = "INSERT INTO auth_users (f_name, l_name, email, username, password)
                       VALUES ('".$safe_f_name."', '".$safe_l_name."','".$safe_email."','".$safe_username."','".$safe_password."')";
	$add_auth_res = mysqli_query($mysqli, $add_auth_sql) or die(mysqli_error($mysqli));

	
	mysqli_close($mysqli);
	$display_block = "<p>Your entry has been added.</p>";
}
?>
<?php include 'BeginNav.php'; ?>
<h1>Add an Entry</h1>
<?php echo $display_block; ?>
<?php include 'EndNav.php';?>