<?php
session_start();
include 'connect.php';
doDB();
 
if (!$_POST)  {
    //haven't seen the selection form, so show it
    $display_block = "<h1>Select an Customer to Update</h1>";
 
    //get parts of records
    $get_list_sql = "SELECT id,
                     CONCAT_WS(', ', L_name, f_name) AS display_name
                     FROM Member_Name ORDER BY L_name, f_name";
    $get_list_res = mysqli_query($mysqli, $get_list_sql) or die(mysqli_error($mysqli));
 
    if (mysqli_num_rows($get_list_res) < 1) {
        //no records
        $display_block .= "<p><em>Sorry, no records to select!</em></p>";
 
    } else {
        //has records, so get results and print in a form
        $display_block .= "
        <form method=\"post\" action=\"".$_SERVER['PHP_SELF']."\">
        <p><label for=\"change_id\">Select a Record to Update:</label><br/>
        <select id=\"change_id\" name=\"change_id\" required=\"required\">
        <option value=\"\">-- Select One --</option>";
 
        while ($recs = mysqli_fetch_array($get_list_res)) {
            $id = $recs['id'];
            $display_name = stripslashes($recs['display_name']);
            $display_block .= "<option value=\"".$id."\">".$display_name."</option>";
        }
 
        $display_block .= "
        </select></p>
        <button class='btn-success' type='submit' name='submit' value='change'>Change Selected Entry</button>
        </form>";
    }
    //free result
    mysqli_free_result($get_list_res);
 
} else if ($_POST) {
    //check for required fields
    if ($_POST['change_id'] == "")  {
        header("Location: updatemember.php");
        exit;
    }
 
    //create safe version of ID
    $safe_id = mysqli_real_escape_string($mysqli, $_POST['change_id']);
    $_SESSION["id"]=$safe_id;
    $_SESSION["address"]="true";
    $_SESSION["personalinfo"]="true";
   // $_SESSION["email"]="true";
   //$_SESSION["fax"]="true";
    $_SESSION["notes"]="true";
    //get master_info
    $get_master_sql = "SELECT f_name, L_name FROM Member_Name WHERE id = '".$safe_id."'";
    $get_master_res = mysqli_query($mysqli, $get_master_sql) or die(mysqli_error($mysqli));
 
    while ($name_info = mysqli_fetch_array($get_master_res)) {
        $display_fname = stripslashes($name_info['f_name']);
        $display_Lname = stripslashes($name_info['L_name']);        
    }
 
    $display_block = "<h1>Record Update</h1>";
    $display_block.="<form method='post' action='change.php'>";
    $display_block.="<fieldset><label>First/Last Names:</label><br/>";
    $display_block.="<input type='text' name='f_name' size='20' maxlength='75' required='required' value='" . $display_fname . "'/>";
    $display_block.="<input type='text' name='L_name' size='30' maxlength='75' required='required' value='" . $display_Lname . "'/></fieldset>";
    //free result
    mysqli_free_result($get_master_res);
    //get all addresses
    $get_addresses_sql = "SELECT address, city, state, zipcode, boxtype
                          FROM ShippingInfo WHERE personal_id = '".$safe_id."'";
    $get_addresses_res = mysqli_query($mysqli, $get_addresses_sql) or die(mysqli_error($mysqli));
 
    if (mysqli_num_rows($get_addresses_res) > 0) {
 
        $display_block .= "<p><strong>Addresses:</strong></p>";
 
        while ($add_info = mysqli_fetch_array($get_addresses_res)) {
            $address = stripslashes($add_info['address']);
            $city = stripslashes($add_info['city']);
            $state = stripslashes($add_info['state']);
            $zipcode = stripslashes($add_info['zipcode']);
            $address_type = $add_info['boxtype'];
 
            $display_block .="<p><label for='address'>Street Address:</label><br/>";
            $display_block .="<input type='text' id='address' name='address' size='30' value='".$address."'/></p>";
            $display_block .="<fieldset><label>City/State/Zip:</label><br/>";
            $display_block .="<input type='text' name='city' size='30' maxlength='50' value='" . $city . "'/>";
            $display_block .="<input type='text' name='state' size='5' maxlength='2' value='".$state."'/>";
            $display_block .="<input type='text' name='zipcode' size='10' maxlength='10' value='".$zipcode."'/></fieldset>";
            $display_block .="<fieldset><label>Address Type:</label><br/>";
            if ($address_type=="po"){
                $display_block .="<input type='radio' id='add_type_p' name='add_type' value='po' checked='checked' /><label for='add_type_p'>PO</label>";
                $display_block .="<input type='radio' id='add_type_m' name='add_type' value='mailbox' /><label for='add_type_m'>Mailbox</label>";
                $display_block .="<input type='radio' id='add_type_w' name='add_type' value='work' /><label for='add_type_m'>Work</label>";
            }
            else if ($address_type=="work"){
                $display_block .="<input type='radio' id='add_type_p' name='add_type' value='home'  /><label for='add_type_p'>PO</label>";
                $display_block .="<input type='radio' id='add_type_m' name='add_type' value='work' checked='checked'/><label for='add_type_m'>Mailbox</label>";
                $display_block .="<input type='radio' id='add_type_w' name='add_type' value='other' /><label for='add_type_w'>Work</label>";
            }
            else{
                $display_block .="<input type='radio' id='add_type_p' name='add_type' value='PO' /><label for='add_type_p'>Po</label>";
                $display_block .="<input type='radio' id='add_type_m' name='add_type' value='Mailbox' /><label for='add_type_m'>Mailbox</label>";
                $display_block .="<input type='radio' id='add_type_w' name='add_type' value='Work' checked='checked' /><label for='add_type_w'>Work</label>";
            }   
        }
    $display_block .="</fieldset>";
    }
    else{
    $_SESSION["address"]='false';
    $display_block .= <<<END_OF_BLOCK
    <p><label for="address">Street Address:</label><br/>
    <input type="text" id="address" name="address" size="30" /></p>
 
    <fieldset>
    <label>City/State/Zip:</label><br/>
    <input type="text" name="city" size="30" maxlength="50" />
    <input type="text" name="state" size="5" maxlength="2" />
    <input type="text" name="zipcode" size="10" maxlength="10" />
    </fieldset>
    
    <fieldset>
    <label><br>Address Type:</label><br/>
    <input type="radio" id="add_type_p" name="add_type" value="PO" checked />
        <label for="add_type_p">PO</label>
    <input type="radio" id="add_type_m" name="add_type" value="Mailbox" />
        <label for="add_type_m">Mailbox</label>
    <input type="radio" id="add_type_w" name="add_type" value="Work" />
        <label for="add_type_w">Work</label>
    </fieldset>
END_OF_BLOCK;
    }
 
    //free result
    mysqli_free_result($get_addresses_res);
 
    //get all tel
    $get_personalinfo_sql = "SELECT phone, fax, email FROM Personal_Info
                    WHERE personal_id = '".$safe_id."'";
    $get_personalinfo_res = mysqli_query($mysqli, $get_personalinfo_sql) or die(mysqli_error($mysqli));
 
    if (mysqli_num_rows($get_personalinfo_res) > 0) {
        $display_block .= "<p><strong>Contact Info:</strong></p>";
 
        while ($tel_info = mysqli_fetch_array($get_personalinfo_res)) {
            $phone = stripslashes($tel_info['phone']);
            $fax = stripslashes($tel_info['fax']);
            $email = stripslashes($tel_info['email']);
 
            $display_block .="<fieldset><label>Telephone Number:</label><br/>";
            $display_block .="<input type='text' name='phone' size='30' maxlength='25' value='".$phone."'/>";
            $display_block .="<fieldset><label>Fax Number:</label><br/>";
            $display_block .="<input type='text' name='fax' size='30' maxlength='25' value='".$fax."'/>";
            $display_block .="<fieldset><label>Email:</label><br/>";
            $display_block .="<input type='text' name='email' size='30' maxlength='25' value='".$email."'/>";
            
        }
    $display_block .="</fieldset>";
    }
    else{
    $_SESSION["personalinfo"]='false'; 
    $display_block .= <<<END_OF_BLOCK
    <fieldset>
    <label>Telephone Number:</label><br/>
    <input type="text" name="phone" size="30" maxlength="25" />
    <label>Fax Number:</label><br/>
    <input type="text" name="fax" size="30" maxlength="25" />
    <label>Email:</label><br/>
    <input type="text" name="email" size="30" maxlength="25" />
    </fieldset>
END_OF_BLOCK;
    }
    //free result
    mysqli_free_result($get_personalinfo_res);
 
 
    //get personal note
    $get_notes_sql = "SELECT notes FROM User_Notes
                      WHERE personal_id = '".$safe_id."'";
    $get_notes_res = mysqli_query($mysqli, $get_notes_sql) or die(mysqli_error($mysqli));
 
    if (mysqli_num_rows($get_notes_res) == 1) {
        while ($note_info = mysqli_fetch_array($get_notes_res)) {
            $notes = nl2br(stripslashes($note_info['notes']));
        }
        $display_block .= "<p><label for='notes'>Personal Note:</label><br/>";
        $display_block .= "<textarea id='notes' name='notes' cols='35' rows='3'>".$notes."</textarea></p>";
    }
    else{
    $_SESSION["notes"]='false';
    $display_block .= '<p><label for="notes">Personal Note:</label><br/><textarea id="notes" name="notes" cols="35" rows="3"></textarea></p>';
    }
    
    //free result
    mysqli_free_result($get_notes_res);
 
    $display_block .= "<p style='text-align: left;'><button class='btn-success' type='submit' name='submitChange' id='submitChange' value='submitChange'>Change Customer</button>";
    $display_block .= "&nbsp;&nbsp;&nbsp;&nbsp;<a href='228Final.html' style='color:darkgreen';>Cancel and return to main menu</a></p></form>";
}
//close connection to MySQL
mysqli_close($mysqli);
 
?>
<?php include 'BeginNav.php'; ?>
<?php echo $display_block; ?>
<?php include 'EndNav.php'; ?>
