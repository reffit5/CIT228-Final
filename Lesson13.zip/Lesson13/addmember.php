<?php
include 'connect.php';

if (!$_POST) {
	//haven't seen the form, so show it
	$display_block = <<<END_OF_BLOCK
	<form method="post" action="$_SERVER[PHP_SELF]" class="form">

	<fieldset>
	<label>First Name:</label><br/>
    <input type="text" name="f_name" size="20" maxlength="75" required="required" /><br/>
    <label>Last Name:</label><br/>
	<input type="text" name="L_name" size="30" maxlength="75" required="required" />
	</fieldset>

	<p><label for="address">Street Address:</label><br/>
	<input type="text" id="address" name="address" size="30" /></p>

	<fieldset>
	<label>City:</label><br/>
    <input type="text" name="city" size="30" maxlength="50" /><br/>
    <label>State:</label><br/>
    <input type="text" name="state" size="5" maxlength="2" /><br/>
    <label>Zip:</label><br/>
	<input type="text" name="zipcode" size="10" maxlength="10" /><br/>
	</fieldset>

	<fieldset>
	<br>
	<label>Address Type:</label><br/>
	<input type="radio" id="add_type_p" name="add_type" value="PO" checked />
	    <label for="add_type_p">PO</label>
	<input type="radio" id="add_type_w" name="add_type" value="WORK" />
	    <label for="add_type_w">work</label>
	<input type="radio" id="add_type_m" name="add_type" value="MAILBOX" />
	    <label for="add_type_m">mail box</label>
	</fieldset>

	<fieldset>
    <h1>Contact Info</h1><br/>
    <label>Phone Number:</label><br/>
	<input type="text" name="phone" size="30" maxlength="25" /><br/>
    <label> Fax Number: </label><br/>
    <input type="text" name="fax" size="30" maxlength="25"/><br/>
    <label> Email Adress:</label><br/>
    <input type="text" name="email" size="30" maxlength="25"/><br/>
	</fieldset>

	<p><label for="notes">Personal Note:</label><br/>
	<textarea id="notes" name="notes" cols="35" rows="3"></textarea></p>

	<button type="submit" name="submit" value="send" class="bg-success">Add Member</button>
	</form>
END_OF_BLOCK;

} else if ($_POST) {
	//time to add to tables, so check for required fields
	if (($_POST['f_name'] == "") || ($_POST['L_name'] == "")) {
		header("Location: addmember.php");
		exit;
	}

	//connect to database
	doDB();

	//create clean versions of input strings
	$safe_f_name = mysqli_real_escape_string($mysqli, $_POST['f_name']);
	$safe_l_name = mysqli_real_escape_string($mysqli, $_POST['L_name']);
	$safe_address = mysqli_real_escape_string($mysqli, $_POST['address']);
	$safe_city = mysqli_real_escape_string($mysqli, $_POST['city']);
	$safe_state = mysqli_real_escape_string($mysqli, $_POST['state']);
	$safe_zipcode = mysqli_real_escape_string($mysqli, $_POST['zipcode']);
	$safe_tel_number = mysqli_real_escape_string($mysqli, $_POST['phone']);
	$safe_fax_number = mysqli_real_escape_string($mysqli, $_POST['fax']);
	$safe_email = mysqli_real_escape_string($mysqli, $_POST['email']);
	$safe_notes = mysqli_real_escape_string($mysqli, $_POST['notes']);

	//add to master_name table
	$add_master_sql = "INSERT INTO Member_Name (f_name, L_name)
                       VALUES ('".$safe_f_name."', '".$safe_l_name."')";
	$add_master_res = mysqli_query($mysqli, $add_master_sql) or die(mysqli_error($mysqli));

	//get master_id for use with other tables
	$personal_id = mysqli_insert_id($mysqli);

	if (($_POST['address']) || ($_POST['city']) || ($_POST['state']) || ($_POST['zipcode'])) {
		//something relevant, so add to address table
		$add_address_sql = "INSERT INTO ShippingInfo (personal_id,
		                    address, city, state, zipcode, boxtype)  VALUES ('".$personal_id."',
		                     '".$safe_address."', '".$safe_city."',
						'".$safe_state."' , '".$safe_zipcode."' , '".$_POST['add_type']."')";
		$add_address_res = mysqli_query($mysqli, $add_address_sql) or die(mysqli_error($mysqli));
	}

	if (($_POST['phone']) || ($_POST['fax']) || ($_POST['email'])) {
		//something relevant, so add to address table
		$add_personalinfo_sql = "INSERT INTO Personal_Info (personal_id,
		                    phone, fax, email )  VALUES ('".$personal_id."',
		                     '".$safe_tel_number."', '".$safe_fax_number."',
							'".$safe_email."' )";
		$add_personalinfo_res = mysqli_query($mysqli, $add_personalinfo_sql) or die(mysqli_error($mysqli));
	}

	if (($_POST['notes'])) {
			//something relevant, so add to notes table
			$add_notes_sql = "INSERT INTO User_Notes (personal_id,
			                  notes)  VALUES ('".$personal_id."', '".$safe_notes."')";
			$add_notes_res = mysqli_query($mysqli, $add_notes_sql) or die(mysqli_error($mysqli));
		}
	mysqli_close($mysqli);
	$display_block = "<p>Your Customer has been added.</p>";
}
?>
<?php include 'BeginNav.php'; ?>
<h1>Add an Entry</h1>
<?php echo $display_block; ?>
<?php include 'EndNav.php';?>