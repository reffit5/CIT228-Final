<?php
session_start();
//connect to database
include 'connect.php';
 
//time to update tables, so check for required fields
    if (($_POST['f_name'] == "") || ($_POST['L_name'] == "")) {
        header("Location: updatemember.php");
        exit;
    }
    //connect to database
    doDB();
    //create clean versions of input strings
    $personal_id=$_SESSION["id"];
    $safe_f_name = mysqli_real_escape_string($mysqli, $_POST['f_name']);
    $safe_l_name = mysqli_real_escape_string($mysqli, $_POST['L_name']);
    $safe_address = mysqli_real_escape_string($mysqli, $_POST['address']);
    $safe_city = mysqli_real_escape_string($mysqli, $_POST['city']);
    $safe_state = mysqli_real_escape_string($mysqli, $_POST['state']);
    $safe_zipcode = mysqli_real_escape_string($mysqli, $_POST['zipcode']);
    $safe_tel_number = mysqli_real_escape_string($mysqli, $_POST['phone']);
    $safe_fax_number = mysqli_real_escape_string($mysqli, $_POST['fax']);
    $safe_email = mysqli_real_escape_string($mysqli, $_POST['email']);
    $safe_note = mysqli_real_escape_string($mysqli, $_POST['notes']);
    
    //update master_name table
    $add_master_sql = "UPDATE Member_Name SET f_name='".$safe_f_name."',L_name='". $safe_l_name."'".
                       "WHERE id=".$personal_id;
    $add_master_res = mysqli_query($mysqli, $add_master_sql) or die(mysqli_error($mysqli));
 
    if ($_SESSION["address"]=="true"){
        //update address table
        $add_address_sql = "UPDATE ShippingInfo SET personal_id=".$personal_id.", address='". $safe_address ."', city='". $safe_city ."', state='". $safe_state .
                            "', zipcode='". $safe_zipcode ."', boxtype='".$_POST['add_type']."'".
                             "WHERE personal_id=".$personal_id;
        $add_address_res = mysqli_query($mysqli, $add_address_sql) or die(mysqli_error($mysqli));
        }
     else if (($_POST['address']) || ($_POST['city']) || ($_POST['state']) || ($_POST['zipcode'])) {
        //add new record to table
        $add_address_sql = "INSERT INTO ShippingInfo (personal_id, address, city, state, zipcode, boxtype)  VALUES ('".
                            $personal_id."', '".$safe_address."', '".$safe_city.
                            "','".$safe_state."' , '".$safe_zipcode."' , '".$_POST['add_type']."')";
        $add_address_res = mysqli_query($mysqli, $add_address_sql) or die(mysqli_error($mysqli));
    }
 
    if ($_SESSION["personalinfo"]=="true"){
        //update telephone table
        $add_personalinfo_sql = "UPDATE Personal_Info SET personal_id=".$personal_id.", phone='".$safe_tel_number."', fax='".$safe_fax_number."', email='".$safe_email."'".
                         "WHERE personal_id=".$personal_id;
        $add_personalinfo_res = mysqli_query($mysqli, $add_personalinfo_sql) or die(mysqli_error($mysqli));
       } else if (($_POST['phone']) || ($_POST['fax']) || ($_POST['email'])){
       // add new record to telephone table
        $add_personalinfo_sql = "INSERT INTO Personal_Info (personal_id,
                        phone, fax, email )  VALUES ('".$personal_id."',
                        '".$safe_tel_number."', '".$safe_fax_number."', '".$safe_email."')";
        $add_personalinfo_res = mysqli_query($mysqli, $add_personalinfo_sql) or die(mysqli_error($mysqli));
       }
    
 
    if ($_SESSION["notes"]=="true"){
        //update notes table
        $add_notes_sql = "UPDATE User_Notes SET personal_id=".$personal_id.",notes='".$safe_note."'".
                          "WHERE personal_id=".$personal_id;
        $add_notes_res = mysqli_query($mysqli, $add_notes_sql) or die(mysqli_error($mysqli));
    } else  if ($_POST['notes']) {
      // add new record to notes table
        $add_notes_sql = "INSERT INTO User_Notes (personal_id,
                          notes)  VALUES ('".$master_id."', '".$safe_note."')";
        $add_notes_res = mysqli_query($mysqli, $add_notes_sql) or die(mysqli_error($mysqli));
    }
 
    mysqli_close($mysqli);
    $display_block = "<p>Your entry has been changed...</p>";
 
?>
<?php include 'BeginNav.php'; ?>
<?php echo $display_block; ?>
<?php include 'EndNav.php'; ?>
