<?php
echo'<!DOCTYPE html>
<html>
<head>
<title>Pet Purchase Place</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link href="style.css" type="text/css" rel="stylesheet"/>
</style>
</head>
<body>
<h1>Pet Purchase Place</h1>
<h2>Create an account so we have your shipping info</h2>
<article class="container-fluid">
    <nav class="navbar navbar-expand-sm bg-info">
    <a class="navbar-brand" href="228Final.html">PPP</a>
    <!-- Links -->
    <ul class="navbar-nav">
    <li class="nav-item">
    <a class="nav-link" href="view.php">View Members</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="updatemember.php">Update Member</a>
        </li>
    <li class="nav-item">
    <a class="nav-link" href="addmember.php">Add Member</a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="deletemember.php">Remove Member</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="addAuthUser.php">Add Admin</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="deleteAuthUser.php">Remove Admin</a>
            </li>
            <li class="nav-item">
    <a class="nav-link" href="jsonwrite.php">Create json</a>
      </li>
     <li class="nav-item">
    <a class="nav-link" href="jsonview.php">View json</a>
    </li>
            </ul>
    </nav>
</body>
</html>'?>