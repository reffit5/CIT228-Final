<?php 
include 'connect.php';
doDB();
 
$query="SELECT id, f_Name, L_Name FROM Member_Name"; 
$result=$mysqli->query($query)
    or die ($mysqli->error);
 
//store the entire response
$response = array();
 
//the array that will hold the titles and links
$posts = array();
 
while($row=$result->fetch_assoc()) //mysql_fetch_array($sql)
{ 
$id=$row['id']; 
$fName=$row['f_Name']; 
$lName=$row['L_Name']; 
 
//each item from the rows go in their respective vars and into the posts array
$posts[] = array( 'id'=> $id, 'f_Name'=> $fName, 'L_Name'=>$lName); 
 
} 
 
//the posts array goes into the response
$response['contactList'] = $posts;
 
//creates the file
$myFile = fopen("CustomerInfo.json", "w");
fwrite($myFile, json_encode($response));
fclose($myFile);
include 'BeginNav.php';
$display_block="<p>The contact list has been written to json</p>";
$display_block.="<p><a href='jsonview.php'>View customer info</a></p>";
echo $display_block;
include 'EndNav.php';
?> 
