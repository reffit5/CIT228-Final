<?php
include 'connect.php';
doDB();
if (!$_POST)  {
	//haven't seen the selection form, so show it
	$display_block = "<h1>Select an Customer</h1>";

	//get parts of records
	$get_list_sql = "SELECT id,
	                 CONCAT_WS(', ', L_name, f_name) AS display_name
	                 FROM Member_Name ORDER BY L_name, f_name";
	$get_list_res = mysqli_query($mysqli, $get_list_sql) or die(mysqli_error($mysqli));

	if (mysqli_num_rows($get_list_res) < 1) {
		//no records
		$display_block .= "<p><em>Sorry, no records to select!</em></p>";

	} else {
		//has records, so get results and print in a form
		$display_block .= "
		<form method=\"post\" action=\"".$_SERVER['PHP_SELF']."\">
		<p><label for=\"sel_id\">Select a Record:</label><br/>
		<select id=\"sel_id\" name=\"sel_id\" required=\"required\">
		<option value=\"\">-- Select One --</option>";

		while ($recs = mysqli_fetch_array($get_list_res)) {
			$id = $recs['id'];
			$display_name = stripslashes($recs['display_name']);
			$display_block .= "<option value=\"".$id."\">".$display_name."</option>";
		}

		$display_block .= "
		</select></p>
		<button class='btn-success' type='submit' name='submit' value='view'>View Selected Entry</button>
		</form>";
	}
	//free result
	mysqli_free_result($get_list_res);

} else if ($_POST) {
	//check for required fields
	if ($_POST['sel_id'] == "")  {
		header("Location: view.php");
		exit;
	}

	//create safe version of ID
	$safe_id = mysqli_real_escape_string($mysqli, $_POST['sel_id']);

	//get master_info
	$get_master_sql = "SELECT concat_ws(' ', f_name, L_name) as display_name
	                   FROM Member_Name WHERE id = '".$safe_id."'";
	$get_master_res = mysqli_query($mysqli, $get_master_sql) or die(mysqli_error($mysqli));

	while ($name_info = mysqli_fetch_array($get_master_res)) {
		$display_name = stripslashes($name_info['display_name']);
	}

	$display_block = "<h1>Showing Record for ".$display_name."</h1>";

	//free result
	mysqli_free_result($get_master_res);

	//get all addresses
	$get_addresses_sql = "SELECT address, city, state, zipcode, boxtype
	                      FROM ShippingInfo WHERE personal_id = '".$safe_id."'";
	$get_addresses_res = mysqli_query($mysqli, $get_addresses_sql) or die(mysqli_error($mysqli));

 	if (mysqli_num_rows($get_addresses_res) > 0) {

		$display_block .= "<p><strong>Addresses: </strong><br/>
		<ul>";

		while ($add_info = mysqli_fetch_array($get_addresses_res)) {
			$address = stripslashes($add_info['address']);
			$city = stripslashes($add_info['city']);
			$state = stripslashes($add_info['state']);
			$zipcode = stripslashes($add_info['zipcode']);
			$boxtype = $add_info['boxtype'];

			$display_block .= "<li>Street: $address City: $city State: $state Zipcode: $zipcode ($boxtype)</li>";
		}

		$display_block .= "</ul>";
	}

	//free result
	mysqli_free_result($get_addresses_res);

	//get all tel
	$get_personalinfo_sql = "SELECT phone, fax, email FROM Personal_Info
	                WHERE personal_id = '".$safe_id."'";
	$get_personalinfo_res = mysqli_query($mysqli, $get_personalinfo_sql) or die(mysqli_error($mysqli));

	if (mysqli_num_rows($get_personalinfo_res) > 0) {

		$display_block .= "<p><strong>Contact Info:</strong><br/>
		<ul>";

		while ($tel_info = mysqli_fetch_array($get_personalinfo_res)) {
			$phone = stripslashes($tel_info['phone']);
			$fax = stripslashes($tel_info['fax']);
			$email = stripslashes($tel_info['email']);

			$display_block .= "<li>Phone: $phone Fax: $fax Email: $email</li>";
		}

		$display_block .= "</ul>";
	}

	//free result
	mysqli_free_result($get_personalinfo_res);
	

	//get personal note
	$get_notes_sql = "SELECT notes FROM User_Notes
	                  WHERE personal_id = '".$safe_id."'";
	$get_notes_res = mysqli_query($mysqli, $get_notes_sql) or die(mysqli_error($mysqli));

	if (mysqli_num_rows($get_notes_res) == 1) {
		while ($note_info = mysqli_fetch_array($get_notes_res)) {
			$notes = nl2br(stripslashes($note_info['notes']));
		}

		$display_block .= "<p><strong>Personal Notes:</strong><br/>$notes</p>";
	}

	//free result
	mysqli_free_result($get_notes_res);

}
//close connection to MySQL
mysqli_close($mysqli);
?>
<?php include 'BeginNav.php'; ?>
<?php echo $display_block; ?>
<?php include 'EndNav.php'; ?>
